define( function ( require ) {

	"use strict";

	return {
		app_slug : 'golden-tower',
		wp_ws_url : 'http://goldentower-ye.com/wp-appkit-api/golden-tower',
		wp_url : 'http://goldentower-ye.com',
		theme : 'q-android',
		version : '1.0.0',
		app_title : 'Golden Tower',
		app_platform : 'android',
		gmt_offset : 3,
		debug_mode : 'off',
		auth_key : 'kvmni6du3nbzatrw8spltf4jszpnzpzzcqwqqd8nybfww4rgi6jcb2nvmq6jaeup',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
